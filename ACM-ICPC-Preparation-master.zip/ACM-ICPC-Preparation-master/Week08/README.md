# Week 8


## Questions from previous topics