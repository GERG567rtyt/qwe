# Week 12


## Strings

#### [Tutorial]()

#### Other Study Sources


## Tries

#### [Tutorial]()

#### Other Study Sources

#### Source Codes
- Sinan - [C++](Source/trie.cpp)

#### Questions
- [Tries: Contacts](https://www.hackerrank.com/challenges/ctci-contacts)

## Suffix Trees/Arrays

#### [Tutorial]()

#### Other Study Sources
 
#### Source Codes

#### Questions


## Knuth-Morris-Pratt Algorithm (KMP)

#### [Tutorial]()

#### Other Study Sources
 
#### Source Codes

#### Questions


## Rabin-Karp Algorithm

#### [Tutorial]()

#### Other Study Sources
 
#### Source Codes

#### Questions


